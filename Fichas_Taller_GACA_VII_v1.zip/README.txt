# Fichas de Taller · GACA VII — prototipo v1

## Qué incluye
- Alta y edición de fichas de mantenimiento.
- Identificación de equipo, tipo, matrícula/número táctico, modelo, km, horas, fecha, sección y mecánico.
- Listas de filtros, lubricantes y revisiones específicas inspiradas en las fichas fotografiadas.
- Registro de averías, prioridad, estado, observaciones, trabajos realizados y repuestos.
- Historial con búsqueda, lista de averías pendientes y exportación/importación JSON.
- Vista de impresión del formulario para imprimir o guardar como PDF.
- Persistencia local mediante almacenamiento del navegador/WebView; no envía datos a Internet.

## Uso rápido
1. Para probarlo sin instalar, abre `index.html` en un navegador moderno. Para guardar datos de forma persistente, es preferible abrirlo desde un navegador/servidor local o instalar el wrapper Android.
2. En Android Studio, abre la carpeta `android-wrapper` como proyecto Gradle y compila `app` > Build APK.
3. Para PDF, abre una ficha y pulsa «Imprimir / guardar PDF». En Android, elige «Guardar como PDF» si aparece en el diálogo de impresión.
4. En Historial puedes exportar una copia JSON e importarla en otro dispositivo.

## Limitaciones de esta versión
- Es un prototipo inicial; no es una aplicación oficial del Ministerio de Defensa ni está integrada con sistemas de la unidad.
- No incluye firma digital, gestión multiusuario, sincronización ni base de datos cifrada.
- La impresión depende del soporte de impresión del navegador/dispositivo.
- Recomendación: probar primero con datos ficticios. No introducir información clasificada, sensible u operativa sin autorización y validación de seguridad.
